# ShopEZ: One-Stop Shop for Online Purchases

A small e-commerce web app built with the **MERN** stack (MongoDB, Express.js, React, Node.js).
Customers browse products, fill a cart, check out and track their orders. An admin manages products and order status.

Capstone project for the *Full Stack Development with MERN* program (Skill Wallet). Author: **Falin** (Team ID: Individual-Falin).

---

## Features

**Customer**
- Register and log in (passwords hashed with bcrypt, login kept with a JWT token)
- Browse products, search by name, filter by category, sort by price or name
- Product detail page with stock status
- Cart: add, change quantity, remove (saved in the browser, works before login)
- Checkout with shipping address and payment choice (Cash on Delivery, or a demo card option that collects no card data)
- Order confirmation, order history and order tracking (Placed → Shipped → Delivered)
- Cancel an order while it is still "Placed" (stock is returned)

**Admin**
- Dashboard: revenue, orders, customers, products, orders by status, low-stock list, latest orders
- Add, edit and delete products
- See all orders, filter by status, and change an order's status

**Under the hood**
- Prices and stock are always checked on the server; the client total is never trusted
- Stock is reserved safely, so two shoppers can't buy the same last item
- Central error handling with clear JSON messages
- Responsive layout for phones, tablets and desktops

---

## Tech stack

| Part | Technology |
|---|---|
| Frontend | React 18, React Router 6, Axios, Vite, plain CSS |
| Backend | Node.js, Express 4, Mongoose 8 |
| Database | MongoDB (local or MongoDB Atlas) |
| Auth | JSON Web Tokens (jsonwebtoken), bcryptjs |
| Security | helmet, CORS allow-list, input validation |

---

## Folder structure

```
shopez/
├── client/                 React app (Vite)
│   ├── public/images/      product pictures used by the sample data
│   └── src/
│       ├── api/            Axios instance + one function per API call
│       ├── components/     reusable UI pieces (ProductCard, PriceTag, Navbar, …)
│       ├── context/        AuthContext (login state) and CartContext (cart)
│       ├── pages/          one file per screen; pages/admin for the admin panel
│       └── utils/          formatting and price helpers
└── server/                 Express API
    ├── config/             database connection and shared constants
    ├── controllers/        the logic for each endpoint
    ├── middleware/         auth (protect, adminOnly) and error handling
    ├── models/             Mongoose schemas: User, Product, Order
    ├── routes/             URL → controller mapping
    ├── seed/               sample products + seed script
    └── utils/              small helpers (token, async wrapper, errors)
```

---

## Setup

### 1. Prerequisites
- **Node.js 18 or newer** (check with `node -v`)
- **MongoDB**: either
  - a free **MongoDB Atlas** cluster (https://www.mongodb.com/cloud/atlas), or
  - MongoDB Community Server installed on your computer

### 2. Get a MongoDB connection string (Atlas)
1. Create a free cluster (M0).
2. *Database Access*: add a database user with a password.
3. *Network Access*: add your IP address (or `0.0.0.0/0` for testing).
4. *Connect → Drivers*: copy the string, e.g.
   `mongodb+srv://myuser:mypassword@cluster0.xxxxx.mongodb.net/shopez?retryWrites=true&w=majority`
   (put the database name `shopez` before the `?`).

### 3. Install and configure the server
```bash
cd server
npm install
cp .env.example .env        # on Windows: copy .env.example .env
```
Open `server/.env` and set `MONGO_URI` (your connection string) and `JWT_SECRET` (any long random text).

### 4. Load the sample data
```bash
npm run seed
```
This **clears** the database and adds 12 products plus two demo accounts:

| Role | Email | Password |
|---|---|---|
| Admin | admin@shopez.com | Admin@123 |
| Customer | customer@shopez.com | Customer@123 |

### 5. Install the client
```bash
cd ../client
npm install
```

---

## Running the app

Use two terminals.

```bash
# Terminal 1 – backend (http://localhost:5000)
cd server
npm start          # or: npm run dev  (restarts on file changes)

# Terminal 2 – frontend (http://localhost:5173)
cd client
npm start
```

Open **http://localhost:5173**. The React dev server forwards every `/api` request to the backend, so no extra setup is needed.

Check the API alone: http://localhost:5000/api/health

---

## Testing

**Automated API tests** (Node's built-in test runner, no extra packages). With the server running:

```bash
cd server
npm test
```

They check the health endpoint, product search and filters, register/login (including wrong password and duplicate email), 401/403 rules, placing an order with server-side prices and stock reduction, admin status changes, and that cancelling returns the stock. The tests clean up after themselves (the test order is cancelled).

**Manual tests:** the UAT document lists 29 test cases (positive and negative) to run in the browser.

---

## API overview

Base URL: `http://localhost:5000/api`. Protected routes need the header `Authorization: Bearer <token>`.

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | /auth/register | Public | Create a customer account |
| POST | /auth/login | Public | Log in, returns token + user |
| GET | /auth/me | Logged in | Current user |
| GET | /products | Public | List (query: `search`, `category`, `sort`) |
| GET | /products/categories | Public | Category list |
| GET | /products/:id | Public | One product |
| POST | /products | Admin | Create product |
| PUT | /products/:id | Admin | Update product |
| DELETE | /products/:id | Admin | Delete product |
| POST | /orders | Logged in | Place an order |
| GET | /orders/my | Logged in | My orders |
| GET | /orders/:id | Owner / Admin | One order |
| PUT | /orders/:id/cancel | Owner | Cancel a "Placed" order |
| GET | /orders | Admin | All orders (query: `status`) |
| PUT | /orders/:id/status | Admin | Change order status |
| GET | /admin/stats | Admin | Dashboard numbers |
| GET | /health | Public | API is running |

Errors always come back as `{ "message": "..." }` with a matching HTTP status (400, 401, 403, 404, 500).

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `MongoDB connection error` | Check `MONGO_URI`, the Atlas user/password, and that your IP is allowed in Atlas *Network Access*. |
| `MONGO_URI is missing` / `JWT_SECRET is missing` | You haven't created `server/.env`. Copy `.env.example` to `.env`. |
| Shop page says "Cannot reach the server" | The backend isn't running. Start it in another terminal with `npm start` in `server/`. |
| Port 5000 already in use (common on macOS) | Set `PORT=5050` in `server/.env` and change the proxy target in `client/vite.config.js` to `http://localhost:5050`. |
| Logged out unexpectedly | Your token expired (7 days by default). Log in again. |

---

## License
MIT. Built for learning purposes.
